# pytype
A simple Typing Speed Test right in your terminal made with Python and the curses module.

## Installation
You can install pytype by simply typing in your terminal:
```
pip install pytyping
```

To run the program:
```
pytyping
```
