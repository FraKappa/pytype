# pytype
A simple Typing Speed Test right in your terminal made with Python and the curses module.

![pytype](https://user-images.githubusercontent.com/72104527/112655651-e7a7e500-8e50-11eb-9b46-ecb8df2e10e4.gif)

## Installation
You can install pytype by simply typing in your terminal:
```
pip install pytype
```

To run the program:
```
pytype
```
